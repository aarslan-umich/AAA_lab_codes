import torch
import torch.nn as nn
import torch.nn.functional as F
import pandas as pd
import argparse
from catboost import CatBoostClassifier
from sklearn.preprocessing import StandardScaler
import random
import numpy as np
seed = 123

def set_random(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_random(seed)
parser = argparse.ArgumentParser(description="ParemeterScript")
parser.add_argument("--train_file",required=True,help="Training File is Required")
parser.add_argument("--sample_file",required=True,help="Sample File is Required")
args = parser.parse_args()
train_file = args.train_file
sample_file = args.sample_file
print(f"Train File : {train_file}")
print(f"Sample File : {sample_file}")
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)



class CNN_layer(nn.Module):
    def __init__(self,input=1,output=128,padding='same',kernel=7,dropout=0.4):
        super().__init__()
        self.conv1 = nn.Conv1d(in_channels=input,out_channels=output,kernel_size=kernel,padding=padding)
        self.conv2 = nn.Conv1d(in_channels=output,out_channels=output,kernel_size=kernel,padding=padding)
        self.norm1 = nn.BatchNorm1d(output)
        self.dropout = nn.Dropout(dropout)

    def forward(self,x):
        x= F.elu(self.conv1(x))
        x= F.elu(self.conv2(x))
        x= self.dropout(x)
        x= self.norm1(x)
        return x
    
class CNN_net(nn.Module):
    def __init__(self, dropout=0.4):  
        super().__init__()
        self.layer1 = CNN_layer(input=1,output=128,padding='same',kernel=7,dropout=dropout)
        self.layer2 = CNN_layer(input=128,output=64,padding='same',kernel=5,dropout=dropout)
        self.flatten = nn.Flatten()
        self.dense1 = nn.Linear(31*64,120)
        self.dropout1 = nn.Dropout(dropout)
        self.dense2 = nn.Linear(120,60)
        self.dropout2 = nn.Dropout(dropout)
        self.dense3 = nn.Linear(60,30)
    def forward(self,x):
        x= self.layer1(x)
        x=self.layer2(x)
        x=self.flatten(x)
        x=F.elu(self.dense1(x))
        x=self.dropout1(x)
        x=F.elu(self.dense2(x))
        x= self.dropout2(x)
        x=F.elu(self.dense3(x))
        return x
    

def generate_batch(x,batchsize):
    batches =[]
    for i in range(0,len(x),batchsize):
        batch = x[i:i+batchsize].to_numpy()
        tensor = torch.tensor(batch,dtype=torch.float)
        tensor = tensor.unsqueeze(1)
        batches.append(tensor)
    return batches

scaler = StandardScaler()

data = pd.read_csv(train_file)
Y_train = data["subject"]
X_train = data.drop("subject",axis=1)
X_train = scaler.fit_transform(X_train)
X_train = pd.DataFrame(X_train)
batches = generate_batch(X_train,100000)
train_batch = batches[0]
print(train_batch.shape)



data2 = pd.read_csv(sample_file)
ip_addr = data2["ip_addr"]
time_stamp = data2["time_stamp"]
X_test = data2.drop(["ip_addr","time_stamp"],axis=1)
#X_test = data2.drop(["ipAddress","date"],axis=1)
X_test = scaler.transform(X_test)
X_test = pd.DataFrame(X_test)
test_batch = generate_batch(X_test,2000)
test_batch = test_batch[0]
print(train_batch.shape)


cnn = CNN_net(dropout=0.4)
cnn.eval()
with torch.no_grad():
    train_result  =cnn(train_batch)
    test_result = cnn(test_batch)

train_result =train_result.detach().numpy()
test_result = test_result.detach().numpy()

cat  = CatBoostClassifier(verbose=0, n_estimators=100)
cat.fit(train_result,Y_train)
results = cat.predict(test_result)

df = pd.DataFrame()
df["IP Adress"] = ip_addr
df["Time Stamp"] = time_stamp
df["Result"] = results
print(df)
