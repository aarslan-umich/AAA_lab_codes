import pandas as pd
import argparse
from sklearn.preprocessing import QuantileTransformer


parser = argparse.ArgumentParser(description="ParemeterScript")
parser.add_argument("--train_input_file",required=True,help="Input File is Required")
parser.add_argument("--test_input_file",required=True,help="Input File is Required")

parser.add_argument("--train_output_file",required=True,help="Input File is Required")
parser.add_argument("--test_output_file",required=True,help="Input File is Required")
args = parser.parse_args()
train_input_file = args.train_input_file
train_output_file = args.train_output_file
test_input_file = args.test_input_file
test_output_file = args.test_output_file

train_input= pd.read_csv(train_input_file)
train_columns = train_input.columns
train_subject = train_input["subject"]
train_input = train_input.drop("subject",axis=1)
test_input= pd.read_csv(test_input_file)
test_columns = test_input.columns
test_actual = test_input["ip_addr"]
test_predicted = test_input["time_stamp"]
test_input = test_input.drop(["ip_addr","time_stamp"],axis=1)



transformer = QuantileTransformer(n_quantiles=10, random_state=0, copy=True)
train_input = transformer.fit_transform(train_input)
test_input = transformer.transform(test_input)
train_input = pd.DataFrame(train_input)
test_input = pd.DataFrame(test_input)
train_input.insert(0,"subject",train_subject)
train_input.columns = train_columns
test_input.insert(0,"ip_addr",test_actual )
test_input.insert(1,"time_stamp",test_predicted )
test_input.columns = test_columns
train_input.to_csv(train_output_file,index=0)
test_input.to_csv(test_output_file,index=0)

