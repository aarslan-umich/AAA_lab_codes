import pandas as pd
import argparse

parser = argparse.ArgumentParser(description="ParemeterScript")
parser.add_argument("--input_file",required=True,help="Input File is Required")
parser.add_argument("--output_file",required=True,help="Input File is Required")
args = parser.parse_args()
input_file = args.input_file
output_file = args.output_file


def data_generation(dataset: pd.DataFrame):
    if not isinstance(dataset, pd.DataFrame):
        raise TypeError("You can olnly use Pandas Dataframe")
    sd_factor = [0.5,0.5,0.5,0.03,0.04]
    header = []
    sd=[]
    for i in dataset.columns:
        header.append(i)
        if i =="subject":
            continue
        sd.append(dataset[i].std())

    generated_data = []

    for i in range(len(dataset)):
        generated_data.append(dataset.loc[i].tolist())
        for j in range(5):
            row=[]
            counter = 0
            for k in dataset.columns:
                if k =="subject":
                    row.append(dataset.loc[i,k])
                    continue
                row.append(dataset.loc[i,k]+(sd[counter]*sd_factor[j]))
                counter=counter+1
            generated_data.append(row)
    generated_data = pd.DataFrame(generated_data)
    generated_data.columns = header
    return generated_data

data  = pd.read_csv(input_file)

new_data = data_generation(data)
new_data.to_csv(output_file,index=False)
